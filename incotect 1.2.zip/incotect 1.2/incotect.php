<?php

/**
 * Plugin Name:       Incotect 
 * Plugin URI:        https://www.fiverr.com/rl_soluton
 * Description:       This plugin is used to check if the browser is opened in windows tab. Use the Shortcode to enable incognito detection : [rls_incotect]
 * Version:           1.2
 * Author:            Root Level Solution
 * Author URI:        https://www.fiverr.com/rl_soluton
 */

    function incognito_detect(){
        include 'algo.php';
    }

    add_shortcode('rls_incotect', 'incognito_detect');


 ?>